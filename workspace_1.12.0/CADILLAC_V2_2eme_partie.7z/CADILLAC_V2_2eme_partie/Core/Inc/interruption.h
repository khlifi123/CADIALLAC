/*
 * interruption.h
 *
 *  Created on: Jan 26, 2024
 *      Author: m-ali.khlifi
 */

#ifndef INC_INTERRUPTION_H_
#define INC_INTERRUPTION_H_
double Interruption_1();
double Interruption_2();
double Interruption_3();
double Interruption_4();



#endif /* INC_INTERRUPTION_H_ */
